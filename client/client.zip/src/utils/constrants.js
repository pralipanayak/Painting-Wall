module.exports = {
    SERVER_URL: 'http://localhost:8000',
};
